favorite_fruits = ['bananas', 'apples', 'strawberries']

if 'bananas' in favorite_fruits:
    print("You really like bananas!")

if 'apples' in favorite_fruits:
    print("You really like apples!")

if 'oranges' in favorite_fruits:
    print("You really like oranges!")

if 'grapes' in favorite_fruits:
    print("You really like grapes!")

if 'strawberries' in favorite_fruits:
    print("You really like strawberries!")
