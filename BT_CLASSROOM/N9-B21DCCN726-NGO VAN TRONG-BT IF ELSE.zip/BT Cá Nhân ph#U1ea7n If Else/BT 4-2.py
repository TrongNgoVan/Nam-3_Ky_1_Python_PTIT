# Kiểm tra đẳng thức và bất đẳng thức với chuỗi (string).
name = 'Alice'
print("Is name == 'Alice'? I predict True.")
print(name == 'Alice')
print("\nIs name != 'Bob'? I predict True.")
print(name != 'Bob')
#  print kiểu này sẽ thay thế cho if else
# Kiểm tra sử dụng phương thức lower().
word = 'HELLO'
print("\nIs word.lower() == 'hello'? I predict True.")
print(word.lower() == 'hello')

# Kiểm tra có điều kiện với số trong các trường hợp: đẳng thức, bất đẳng thức, lớn hơn, nhỏ hơn, lớn hơn hoặc bằng, nhỏ hơn hoặc bằng.
age = 25
print("\nIs age == 25? I predict True.")
print(age == 25)
print("\nIs age != 30? I predict True.")
print(age != 30)
print("\nIs age > 18? I predict True.")
print(age > 18)
print("\nIs age < 21? I predict True.")
print(age < 21)
print("\nIs age >= 25? I predict True.")
print(age >= 25)
print("\nIs age <= 20? I predict True.")
print(age <= 20)

# Kiểm tra có điều kiện sử dụng từ khóa and hoặc or.
has_license = True
print("\nIs age >= 18 and has_license == True? I predict True.")
print(age >= 18 and has_license == True)
print("\nIs age < 18 or has_license == False? I predict False.")
print(age < 18 or has_license == False)

# Kiểm tra xem một phần tử có trong danh sách không.
fruits = ['apple', 'banana', 'cherry']
print("\nIs 'banana' in fruits? I predict True.")
print('banana' in fruits)

# Kiểm tra xem một phần tử không có trong danh sách.
print("\nIs 'grape' not in fruits? I predict True.")
print('grape' not in fruits)
