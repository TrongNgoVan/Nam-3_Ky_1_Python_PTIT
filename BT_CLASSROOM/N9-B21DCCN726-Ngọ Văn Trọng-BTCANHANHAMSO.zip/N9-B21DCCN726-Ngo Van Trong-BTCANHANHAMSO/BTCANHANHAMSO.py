# 7.1
def display_message():
    message = "Tôi đang học kiến thức về viết hàm trong Python."
    print(message)
display_message()

# 7.2
def favourite_book(s):
    print("Một trong những cuốn sách yêu thích là "+s)
s=input()
favourite_book(s)

# 7.3
def make_shirt(size, message):
    print(f"Áo có kích thước: {size}")
    print(f"Thông điệp in trên áo: {message}")
make_shirt("L", "I love Python")
make_shirt(size="M", message="Hello World!")

#7.4
def make_shirt(size="Large", message="I love Python"):
    print(f"Áo có kích thước: {size}")
    print(f"Thông điệp in trên áo: {message}")
make_shirt()
make_shirt(size="Medium")
make_shirt(size="Small", message="I love programming")

# 7.5
def description_city (tp,dn="Iceland"):
    print(f"{tp} is in {dn}")
description_city(tp="AAA")
description_city(tp="BBB")
description_city(tp="CCC",dn="Viet Nam")

# 7.6
def city_country(tp,qg):
    print(f"{tp}, {qg}")
city_country("aa","BBB")
city_country("aa","BBB")
city_country("aa","BBB")
# 7.7

def make_album(artist, album_title, num_songs=None):
    album_info = {
        'artist': artist,
        'album_title': album_title,
    }
    if num_songs is not None:
        album_info['num_songs'] = num_songs
    return album_info
album1 = make_album("The Beatles", "Abbey Road")
album2 = make_album("Pink Floyd", "The Dark Side of the Moon", 10)  
album3 = make_album("Led Zeppelin", "IV")

print(album1)
print(album2)
print(album3)

# 7.8

def make_album(artist, album_title, num_songs=None):
    album_info = {
        'artist': artist,
        'album_title': album_title,
    }
    if num_songs is not None:
        album_info['num_songs'] = num_songs
    return album_info

while True:
    print("\nNhập thông tin album nhạc:")
    artist = input("Nghệ sĩ (hoặc 'quit' để thoát): ")
    if artist == 'quit':
        break
    
    album_title = input("Tiêu đề album: ")
    num_songs =   input("Số lượng bài hát (nếu có): ")
    
    if num_songs:
        album = make_album(artist, album_title, num_songs)
    else:
        album = make_album(artist, album_title)
    
    print(f"Thông tin album: {album}")

#7.9
def show_messages(messages):
    for message in messages:
        print(message)
messages_list = [
    "Xin chào!",
    "Cảm ơn bạn!",
    "Chúc một ngày tốt lành!",
    "Hẹn gặp lại!",
]
show_messages(messages_list)
# 7.10
def send_messages(messages, sent_messages):
    """Hàm này in ra thông điệp và chuyển nó vào danh sách sent_messages."""
    while messages:
        current_message = messages.pop()
        print(f"Sending message: {current_message}")
        sent_messages.append(current_message)
messages_to_send = [
    "Chào bạn!",
    "Cảm ơn đã gọi!",
    "Hẹn gặp bạn sau!",
]
sent_messages = []
send_messages(messages_to_send, sent_messages)
print("\nDanh sách các thông điệp ban đầu:")
for message in messages_to_send:
    print(message)

print("\nDanh sách các thông điệp đã gửi:")
for sent_message in sent_messages:
    print(sent_message)
# 7.11
def send_messages(messages, sent_messages):
    """Hàm này in ra thông điệp và chuyển nó vào danh sách sent_messages."""
    while messages:
        current_message = messages.pop()
        print(f"Sending message: {current_message}")
        sent_messages.append(current_message)
messages_to_send = [
    "Chào bạn!",
    "Cảm ơn đã gọi!",
    "Hẹn gặp bạn sau!",
]
sent_messages = []
send_messages(messages_to_send[:], sent_messages)
print("\nDanh sách các thông điệp ban đầu:")
for message in messages_to_send:
    print(message)

print("\nDanh sách các thông điệp đã gửi:")
for sent_message in sent_messages:
    print(sent_message)
# 7.12
def make_sandwich(*items):
    """Hàm này in ra bản tóm tắt về bánh sandwich dựa trên các mục đã chọn."""
    print("Bánh sandwich của bạn bao gồm các mục sau:")
    for item in items:
        print(f"- {item}")
make_sandwich("Thịt gà", "Rau sống", "Sốt mayonnaise")
make_sandwich("Bacon", "Trứng", "Sốt cà chua")
make_sandwich("Hành tây rang", "Phô mai")
# 7.13
def build_profile(first, last, **user_info):
    user_info['first_name'] = first
    user_info['last_name'] = last
    return user_info
my_profile = build_profile('Văn Trọng', 'Ngọ', age=25, city='Thành phố bạn sống', email='email@example.com')
print(my_profile)
# 7.14
def make_car(manufacturer, model, **car_info):
    car_profile = {
        'manufacturer': manufacturer,
        'model': model,
    }
    car_profile.update(car_info)
    return car_profile

car = make_car('subaru', 'outback', color='blue', tow_package=True)

print(car)
#7.15


def print_models(unprinted_designs, completed_models):
    while unprinted_designs:
        current_design = unprinted_designs.pop()
        print(f"Printing model: {current_design}")
        completed_models.append(current_design)

def show_completed_models(completed_models):
    print("\nThe following models have been printed:")
    for completed_model in completed_models:
        print(completed_model)

from print_functions import print_models, show_completed_models

unprinted_designs = ['iphone case', 'robot pendant', 'dodecahedron']
completed_models = []

print("Unprinted models:")
for design in unprinted_designs:
    print(design)
print_models(unprinted_designs, completed_models)
show_completed_models(completed_models)
 #7.16
def my_function():
    print("Chào mừng đến với module của tôi!")
import my_module
# Gọi chức năng từ module bằng cách sử dụng module_name.function_name
my_module.my_function()
#  Nhập một hàm cụ thể từ module
from my_module import my_function

# Gọi hàm trực tiếp
my_function()

#  Nhập một hàm cụ thể từ module và đặt tên tùy ý cho nó
from my_module import my_function as mf

# Gọi hàm bằng tên tùy ý
mf()

#  Nhập toàn bộ module và đặt tên tùy ý cho nó
import my_module as mm

# Gọi chức năng từ module bằng tên tùy ý
mm.my_function()

#  Nhập tất cả các hàm từ module (Không được khuyến nghị vì có thể gây xung đột)
from my_module import *

# Gọi hàm trực tiếp
my_function()




















