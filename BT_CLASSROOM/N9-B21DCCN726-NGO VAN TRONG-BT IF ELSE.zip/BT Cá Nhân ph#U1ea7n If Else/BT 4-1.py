# Kiểm tra với số nguyên
x = 15
print("Is x == 15? I predict True.")
print(x == 15)
print("\nIs x == 20? I predict False.")
print(x == 20)
# print kiểu này sẽ thay thế cho if else
# Kiểm tra với chuỗi
name = 'TRONG'
print("\nIs name == 'TRONG'? I predict True.")
print(name == 'TRONG')
print("\nIs name == 'Bob'? I predict False.")
print(name == 'Bob')

# Kiểm tra với danh sách
fruits = ['apple', 'banana', 'cherry']
print("\nIs 'banana' in fruits? I predict True.")
print('banana' in fruits)
print("\nIs 'grape' in fruits? I predict False.")
print('grape' in fruits)

# Kiểm tra với số thực
temperature = 25.5
print("\nIs temperature > 20? I predict True.")
print(temperature > 20)
print("\nIs temperature < 10? I predict False.")
print(temperature < 10)

# Kiểm tra với logic kết hợp
age = 30
has_license = True
print("\nIs age >= 18 and has_license == True? I predict True.")
print(age >= 18 and has_license == True)
print("\nIs age < 18 or has_license == False? I predict False.")
print(age < 18 or has_license == False)
