# Phiên bản chạy khối if (bắn hạ quái vật màu xanh, kiếm được 5 điểm):
alien_color = 'green'

if alien_color == 'green':
    print("Bạn kiếm được 5 điểm!")
else:
    print("Bạn kiếm được 10 điểm!")
# Phiên bản chạy khối else (bắn hạ quái vật màu đỏ, kiếm được 10 điểm):
alien_color = 'red'

if alien_color == 'green':
    print("Bạn kiếm được 5 điểm!")
else:
    print("Bạn kiếm được 10 điểm!")
