import pandas as pd
import matplotlib.pyplot as plt

# Đọc dữ liệu từ flights.csv và Salaries.csv
flights_data = pd.read_csv('flights.csv')
salaries_data = pd.read_csv('Salaries.csv')

def analyze_and_plot(data, column_name):
    max_value, min_value, mean_value = data[column_name].max(), data[column_name].min(), data[column_name].mean()
    
    print(f"Thống kê cho cột '{column_name}':")
    print(f"   Giá trị lớn nhất: {max_value}")
    print(f"   Giá trị nhỏ nhất: {min_value}")
    print(f"   Giá trị trung bình: {mean_value}")

    plt.scatter(data.index, data[column_name], label='Data Points')
    plt.axhline(y=max_value, color='r', linestyle='--', label='Max Value')
    plt.axhline(y=min_value, color='g', linestyle='--', label='Min Value')
    plt.axhline(y=mean_value, color='b', linestyle='--', label='Mean Value')

    plt.title(f'Biểu đồ scatter cho cột {column_name}')
    plt.xlabel('Index')
    plt.ylabel(column_name)
    plt.legend()
    plt.show()

def plot_flight_variation(data):
    data['date'] = pd.to_datetime(data[['year', 'month', 'day']])
    
    plt.plot(data['date'], data['distance'])
    plt.title('Biểu đồ biến thiên ngày tháng và distance')
    plt.xlabel('Ngày')
    plt.ylabel('Distance')
    plt.show()

def plot_sex_distribution(data):
    sex_counts = data['sex'].value_counts()
    plt.bar(sex_counts.index, sex_counts.values)
    plt.title('Biểu đồ thống kê sex')
    plt.xlabel('Sex')
    plt.ylabel('Số lượng')
    plt.show()

def sort_and_analyze(data, column_name):
    sorted_data = data.sort_values(by=column_name)
    analyze_and_plot(sorted_data, column_name)

# Thực hiện thống kê và vẽ biểu đồ cho flights.csv và Salaries.csv
analyze_and_plot(flights_data, input("Mời bạn nhập tên cột muốn biểu diễn trong bảng flights:"))
analyze_and_plot(salaries_data, input('Mời bạn nhập tên cột muốn biểu diễn trong bảng salary:'))

# Vẽ biểu đồ biến thiên ngày tháng và distance cho flights.csv
plot_flight_variation(flights_data)

# Vẽ biểu đồ thống kê sex đạng cột cho Salaries.csv
plot_sex_distribution(salaries_data)

# Sắp xếp dữ liệu theo tên cột được nhập vào, vẽ và hiển thị biểu đồ tương ứng
table_name = input("Mời bạn nhập tên bảng muốn chọn cột: ")
if table_name in ["Salaries", "flights"]:
    col_name = input("Mời bạn nhập tên cột muốn sắp xếp: ")
    if table_name == "Salaries":
        sort_and_analyze(salaries_data, col_name)
    else:
        sort_and_analyze(flights_data, col_name)
else:
    print("Bảng không hợp lệ.")
