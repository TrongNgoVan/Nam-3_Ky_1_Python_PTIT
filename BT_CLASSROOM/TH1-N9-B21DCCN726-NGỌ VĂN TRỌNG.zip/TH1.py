
def bai_1():
    n=int(input("Nhập số nguyên n: "))
    if(n%3==0 and n>=50 and n<=100): 
        print("True")
    else :
        print("False")
def bai_2():
    a=float(input("Nhập số thực a: "))
    if(a.is_integer()):
        print( "True")
    else:
        print("False")
def bai_3():
    a = int(input("Nhập a: "))
    b = int(input("Nhập b: "))
    c = int(input("Nhập c: "))
    d=(a+b)**c
    if(d>=100 and d<=200):
        print("True")
    else :
        print("False")
def bai_4():

    a = int(input("Nhập a: "))
    b = int(input("Nhập b: "))
    c = int(input("Nhập c: "))
    d= b**2-4*a*c
    if(d>0):
        x1= (-b+ d**0.5)/(2*a)
        x2= (-b- d**0.5)/(2*a)
        print(x1 + " " + x2)
    if(d==0):
        x=-b/(2*a)
        print(x)
    if(d<0):
        print("phuong trinh vo nghiem")
def bai_5():
  
    thang = int(input("Nhập tháng (1-12): "))
    nam = int(input("Nhập năm: "))
    if thang in [1, 3, 5, 7, 8, 10, 12]:
             print("31")
    elif thang == 2:
        if nam % 4 == 0 and (nam % 100 != 0 or nam % 400 == 0):
             print("29")
        else:
             print("28")
    else:
        print("30")

def bai_6():
    toan = float(input("Nhập điểm Toán: "))
    van = float(input("Nhập điểm Văn: "))
    anh = float(input("Nhập điểm Anh: "))
    tb= (toan +van+anh)/3
    if(tb>=8 and( toan>=8 or van>=8) and ( toan>=6.5 and van>=6.5 and anh>=6.5)):
        print("Học sinh giỏi")
    elif (tb>=6.5 and (toan>=6.5 or van>=6.5) and ( toan>=5 and van>=5 and anh>=5)):
        print("Học sinh khá")
    elif(tb>=5 and (toan>=5 or van>=5) and ( toan>=3.5 and van>=3.5 and anh>=3.5)):
        print("Học sinh trung bình")
    elif(tb>=3.5 and (toan>=3.5 or van>=3.5) and ( toan>=2 and van>=2 and anh>=2)):
        print("Học sinh yếu")
    else :
        print("Học sinh kém")
def bai_7():
    n=int(input("Nhập số nguyên n: "))
    s = n*(n+1)/2
    print(s)
def bai_8():
    a=int(input("Nhập số nguyên a: "))
    for i in range(1,a+1):
        if(a%i==0):
            print(i+" ")
def bai_9():
    a = int(input("Nhập số nguyên a: "))
    b = int(input("Nhập số nguyên b: "))
    
    for i in range(1,min(a,b)+1):
        if(a%i==0 and b%i==0):
            print(i+" ")
def bai_10():
    A =int(input("Nhập A: "))
    fb1= 1;
    fb2=1;
    while fb3<=A:
         fb3=fb1+fb2
         fb2=fb3
         fb1=fb2
    print(fb3)
def bai_11(): 
    numbers = []
    while True:
        num = int(input("Nhập số nguyên: "))
        if num == -1:
            break
        numbers.append(num)
    if not numbers:
        print("Dãy số rỗng.")
    else:
        print(f"Số lớn nhất trong dãy là {max(numbers)}")
        print(f"Số bé nhất trong dãy là {min(numbers)}")

def bai_12():
    N = int(input("Nhập số lượng phòng: "))
    doankhach = []
    M = int(input("Nhập số đoàn khách: "))
    for i in range(M):
         khach = int(input(f"Số khách trong đoàn {i + 1}: "))
         doankhach.append(khach)
    phong = [0] * N
    k=0
    for i in range(len(doankhach)):
        if doankhach[i] % 2 == 0:
            for j in range(N):
                if phong[j] == 0:
                    phong[j] = 2
                    doankhach[i] -= 2
                    if doankhach[i] == 0:
                        break
        else:
            for j in range(N):
                if phong[j] == 0:
                    if(doankhach[i]>2):
                        phong[j] = 2
                        doankhach[i] -= 2
                    else:
                        phong[j]=1
                        doankhach[i]-=1
                    if doankhach[i] == 0:
                        break
    if(doankhach[len(doankhach)-1]>0):
        for i in range(len(doankhach)):
            if(doankhach[i]>0):
                for j in range(N):
                    if(phong[j]==1):
                        phong[j]=2
                        doankhach[i]-=1
                        if(doankhach[i]==0):
                            break
    print("Số khách trong từng phòng: ")
    for i in range(N):
        if(i==N-1):
             print(phong[i])
        else:
            print(phong[i],end=',')
               
def bai_13():
    gia_ga_ran = 30000
    gia_hamburger = 25000
    gia_cocacola = 10000
    tong_tien = 0
    mon_an = ["Gà rán", "Hamburger", "Cocacola"]
    so_luong = [int(input("Nhập số lượng Gà rán: ")),
                int(input("Nhập số lượng Hamburger: ")),
                int(input("Nhập số lượng Cocacola: "))]
    if "Gà rán" in mon_an:
        tong_tien += gia_ga_ran * so_luong[mon_an.index("Gà rán")]
    if "Hamburger" in mon_an:
        tong_tien += gia_hamburger * so_luong[mon_an.index("Hamburger")]
    if "Cocacola" in mon_an:
        tong_tien += gia_cocacola * so_luong[mon_an.index("Cocacola")]

    print(f"Tổng tiền: {tong_tien}đ")

if __name__ == "__main__":
    while True:
        print("Chọn bài tập [1-13] hoặc nhập 0 để thoát: ")

        choice = int(input())
        if choice == 0:
            print("Chương trình kết thúc. Hẹn gặp lại!")
            break
        if choice == 1:
           bai_1()  
        elif choice == 2:
           bai_2()
        elif choice == 3:
           bai_3()    
        elif choice == 4:
           bai_4() 
        elif choice == 5:
           bai_5() 
        elif choice == 6:
           bai_6() 
        elif choice == 7:
           bai_7() 
        elif choice == 8:
           bai_8() 
        elif choice == 9:
           bai_9()    
        elif choice == 10:
           bai_10() 
        elif choice == 11:
           bai_11() 
        elif choice == 12:
           bai_12() 
        elif choice == 13:
           bai_13() 

