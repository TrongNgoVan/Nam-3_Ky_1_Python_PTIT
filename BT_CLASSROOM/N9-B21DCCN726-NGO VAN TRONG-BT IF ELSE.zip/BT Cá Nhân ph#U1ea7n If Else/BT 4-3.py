# Phiên bản với kiểm tra if (in ra thông điệp nếu bắn hạ quái vật màu xanh):
alien_color = 'green'

if alien_color == 'green':
    print("Bạn kiếm được 5 điểm!")
# Phiên bản không thành công (không có đầu ra):
alien_color = 'red'
if alien_color == 'green':
    print("Bạn kiếm được 5 điểm!")
