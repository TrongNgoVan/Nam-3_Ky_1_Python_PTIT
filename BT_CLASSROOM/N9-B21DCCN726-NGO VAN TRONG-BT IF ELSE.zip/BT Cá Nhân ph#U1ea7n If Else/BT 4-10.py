# Danh sách tên người dùng hiện tại
current_users = ['John', 'emma', 'jaden', 'alice', 'admin']

# Danh sách tên người dùng mới
new_users = ['Jaden', 'Alice', 'Lucas', 'Olivia', 'Grace']

# Tạo bản sao của danh sách current_users với tất cả các tên viết thường
current_users_lower = [user.lower() for user in current_users]

# Lặp qua danh sách new_users để kiểm tra tên người dùng mới
for new_user in new_users:
    if new_user.lower() in current_users_lower:
        print(f"Tài khoản '{new_user}' đã được sử dụng, bạn cần nhập tên người dùng mới.")
    else:
        print(f"Tài khoản '{new_user}' khả dụng.")
