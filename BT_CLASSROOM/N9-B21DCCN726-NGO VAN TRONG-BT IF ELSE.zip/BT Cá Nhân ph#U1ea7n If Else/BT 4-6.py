age = 30

if age < 2:
    stage_of_life = "baby"
elif age >= 2 and age < 4:
    stage_of_life = "toddler"
elif age >= 4 and age < 13:
    stage_of_life = "kid"
elif age >= 13 and age < 20:
    stage_of_life = "teenager"
elif age >= 20 and age < 65:
    stage_of_life = "adult"
else:
    stage_of_life = "elder"

print(f"At age {age}, you are considered as an {stage_of_life}.")
