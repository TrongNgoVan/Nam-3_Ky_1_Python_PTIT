usernames = ['admin', 'jaden', 'emma', 'john', 'quản trị viên']
name = str(input())

if name == 'admin':
    print("Xin chào quản trị viên, bạn có muốn xem báo cáo trạng thái không?")
elif name=='admin' or name== 'jaden' or name=='emma'or name=='john':
    print(f"Xin chào {name}, cảm ơn vì đăng nhập lại.")
