# Phiên bản với quái vật màu xanh (5 điểm):
alien_color = 'green'

if alien_color == 'green':
    print("Bạn kiếm được 5 điểm!")
elif alien_color == 'yellow':
    print("Bạn kiếm được 10 điểm!")
else:
    print("Bạn kiếm được 15 điểm!")
# Phiên bản với quái vật màu vàng (10 điểm):
alien_color = 'yellow'

if alien_color == 'green':
    print("Bạn kiếm được 5 điểm!")
elif alien_color == 'yellow':
    print("Bạn kiếm được 10 điểm!")
else:
    print("Bạn kiếm được 15 điểm!")
# Phiên bản với quái vật màu đỏ (15 điểm):
alien_color = 'red'

if alien_color == 'green':
    print("Bạn kiếm được 5 điểm!")
elif alien_color == 'yellow':
    print("Bạn kiếm được 10 điểm!")
else:
    print("Bạn kiếm được 15 điểm!")
