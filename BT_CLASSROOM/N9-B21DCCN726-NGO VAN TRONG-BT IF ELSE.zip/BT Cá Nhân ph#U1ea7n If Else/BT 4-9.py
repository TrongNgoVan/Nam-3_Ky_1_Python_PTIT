usernames = ['admin', 'jaden', 'emma', 'john', 'quản trị viên']

if usernames:
    for username in usernames:
        if username.lower() == 'quản trị viên':
            print("Xin chào quản trị viên, bạn có muốn xem báo cáo trạng thái không?")
        else:
            print(f"Xin chào {username}, cảm ơn vì đăng nhập lại.")
else:
    print("We need to find some users!")

# Xóa tất cả tên người dùng khỏi danh sách
usernames.clear()

# Kiểm tra lại danh sách
if usernames:
    for username in usernames:
        if username.lower() == 'quản trị viên':
            print("Xin chào quản trị viên, bạn có muốn xem báo cáo trạng thái không?")
        else:
            print(f"Xin chào {username}, cảm ơn vì đăng nhập lại.")
else:
    print("We need to find some users!")
